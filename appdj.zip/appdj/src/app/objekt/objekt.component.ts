import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objekt',
  templateUrl: './objekt.component.html',
  styleUrls: ['./objekt.component.css']
})
export class ObjektComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
