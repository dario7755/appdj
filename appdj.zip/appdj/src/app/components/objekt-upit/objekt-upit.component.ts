import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objekt-upit',
  templateUrl: './objekt-upit.component.html',
  styleUrls: ['./objekt-upit.component.css']
})
export class ObjektUpitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
