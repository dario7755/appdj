import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ObjektUpitComponent } from './objekt-upit.component';

describe('ObjektUpitComponent', () => {
  let component: ObjektUpitComponent;
  let fixture: ComponentFixture<ObjektUpitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ObjektUpitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjektUpitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
