import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ObjektListaComponent } from './objekt-lista.component';

describe('ObjektListaComponent', () => {
  let component: ObjektListaComponent;
  let fixture: ComponentFixture<ObjektListaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ObjektListaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjektListaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
