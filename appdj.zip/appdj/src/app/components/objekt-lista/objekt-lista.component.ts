import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objekt-lista',
  templateUrl: './objekt-lista.component.html',
  styleUrls: ['./objekt-lista.component.css']
})
export class ObjektListaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
