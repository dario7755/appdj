import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ObjektNoviComponent } from './objekt-novi.component';

describe('ObjektNoviComponent', () => {
  let component: ObjektNoviComponent;
  let fixture: ComponentFixture<ObjektNoviComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ObjektNoviComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjektNoviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
