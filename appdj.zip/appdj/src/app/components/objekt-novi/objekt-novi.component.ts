import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objekt-novi',
  templateUrl: './objekt-novi.component.html',
  styleUrls: ['./objekt-novi.component.css']
})
export class ObjektNoviComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
