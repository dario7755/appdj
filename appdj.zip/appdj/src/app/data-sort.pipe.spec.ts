import { DataSortPipe } from './data-sort.pipe';

describe('DataSortPipe', () => {
  it('create an instance', () => {
    const pipe = new DataSortPipe();
    expect(pipe).toBeTruthy();
  });
});
