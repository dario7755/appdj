const mySecret = "MY_SECRET";

module.exports = { mySecret };