import { Osoba } from './osoba';

export class Osobe {
    osobe: Osoba[];    
}