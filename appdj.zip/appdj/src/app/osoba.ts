export class Osoba {
    id: number;
    ime: string;
    prezime: string;
	iq: number;
	t: number;
    emailId: string;    
}